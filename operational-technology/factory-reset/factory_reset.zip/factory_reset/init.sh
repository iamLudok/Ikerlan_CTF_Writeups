#!/bin/bash

sudo docker build -t factory_reset .
sudo docker run --rm --name factory_reset -p8000:5000 -d factory_reset
