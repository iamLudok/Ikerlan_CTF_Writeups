function refreshData() {
    fetch('/api/data')
        .then(response => response.json())
        .then(data => {
            document.getElementById('tank1-temp').textContent = data.tank1_temp.toFixed(1) + '°C';
            document.getElementById('tank1-pressure').textContent = data.tank1_pressure.toFixed(1) + ' bar';
            document.getElementById('tank2-temp').textContent = data.tank2_temp.toFixed(1) + '°C';
            document.getElementById('tank2-pressure').textContent = data.tank2_pressure.toFixed(1) + ' bar';
            document.getElementById('prod-rate').textContent = data.production_rate + ' units/h';
            document.getElementById('alarm').textContent = data.alarm_status;
        })
        .catch(error => console.error('Error:', error));
}

// Auto-refresh cada 5 segundos
setInterval(refreshData, 5000);
