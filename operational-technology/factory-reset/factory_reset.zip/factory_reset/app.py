from flask import Flask, render_template, request, jsonify, redirect, url_for
import os
import time
import random
import subprocess

app = Flask(__name__)
app.config['SECRET_KEY'] = 'factory_default_key_2025'
app.config['DEBUG'] = True

system_data = {
    'tank1_temp': 85.4,
    'tank1_pressure': 2.3,
    'tank2_temp': 92.1,
    'tank2_pressure': 1.8,
    'production_rate': 150,
    'alarm_status': 'OK',
    'last_update': time.time()
}

DEFAULT_CREDENTIALS = {
    'admin': 'admin123',
    'operator': 'operator',
    'maintenance': 'factory2025'
}

@app.route('/')
def index():
    return render_template('index.html', data=system_data)

@app.route('/api/data')
def get_data():
    system_data['tank1_temp'] += random.uniform(-1, 1)
    system_data['tank2_temp'] += random.uniform(-1, 1)
    system_data['last_update'] = time.time()
    return jsonify(system_data)

@app.route('/admin')
def admin():
    return render_template('admin.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/authenticate', methods=['POST'])
def authenticate():
    username = request.form.get('username')
    password = request.form.get('password')
    
    if username in DEFAULT_CREDENTIALS and DEFAULT_CREDENTIALS[username] == password:
        log_entry = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Login successful for user: {username}"
        with open('/app/logs/system.log', 'a') as f:
            f.write(log_entry + '\n')
        return redirect(url_for('admin'))
    else:
        log_entry = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Login failed for user: {username}"
        with open('/app/logs/system.log', 'a') as f:
            f.write(log_entry + '\n')
        return "Login failed", 401

@app.route('/logs')
def view_logs():
    try:
        with open('/app/logs/system.log', 'r') as f:
            logs = f.read()
        return f"<pre>{logs}</pre>"
    except FileNotFoundError:
        return "No logs found", 404

@app.route('/debug')
def debug_info():
    if app.config.get('DEBUG'):
        return jsonify({
            'version': '1.0.0',
            'environment': 'development',
            'default_users': list(DEFAULT_CREDENTIALS.keys()),
            'endpoints': ['/admin', '/logs', '/debug', '/api/data', '/maintenance/command'],
            'hint': 'maintenance users have diagnostic privileges; check admin panel for tools'
        })
    return "Debug disabled", 403

@app.route('/maintenance/command', methods=['POST'])
def run_command():
    username = request.form.get('username')
    if username != 'maintenance':
        return "Access denied: maintenance role required", 403

    component = request.form.get('component')
    if not component:
        return "No component name provided", 400

    try:
        backup_file = f"/app/backups/{component}_{time.strftime('%Y%m%d_%H%M%S')}.tar.gz"
        command = f"tar -czf {backup_file} /app/{component} 2>&1"
        result = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
        return f"<pre>Backup created for component '{component}':\n{result.decode('utf-8')}</pre>"
    except subprocess.CalledProcessError as e:
        return f"<pre>Error during backup:\n{e.output.decode('utf-8')}</pre>", 500
    except Exception as e:
        return f"Unexpected error: {str(e)}", 500
