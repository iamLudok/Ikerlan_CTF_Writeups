import sys
import signal

def timeout_handler(signum, frame):
    print("\nTime's up! Connection closed.")
    sys.exit(0)

def banner():
    print("╔════════════════════════════════════════╗")
    print("║            PYTHON JAIL v1.0            ║")
    print("║         Can you escape the jail?       ║")
    print("╚════════════════════════════════════════╝")
    print()

def check_input(user_input):
    banned = ['file', 'open', 'os']
    
    if len(user_input) > 200:
        return False
        
    for word in banned:
        if word in user_input.lower():
            print(word)
            return False
    return True

def main():
    signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(300)
    
    banner()
    print("Welcome to the Python Jail v2!")
    print("Try to read the flag from 'flag.txt'")
    print("Some words are forbidden... can you find another way?")
    print("Type 'quit' to exit")
    print("You have 5 minutes!")
    print()
    
    command_count = 0
    max_commands = 20
    
    while command_count < max_commands:
        try:
            user_input = input("jail> ")
            command_count += 1
            
            if user_input.lower() == 'quit':
                print("Goodbye!")
                break
                
            if not check_input(user_input):
                print("Forbidden word detected!")
                continue
            
            try:
                exec(user_input)
            except Exception as e:
                print(f"Error: {e}")
            
        except KeyboardInterrupt:
            print("\nGoodbye!")
            break
        except EOFError:
            break
    
    if command_count >= max_commands:
        print("Command limit reached! Connection closed.")

if __name__ == "__main__":
    main()
