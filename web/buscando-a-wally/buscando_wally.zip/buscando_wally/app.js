const express = require('express');
const servidor = express();
const fs = require('fs');
const path = require('path');

const FLAG_INTERNA = "ikerlan{fake}";

const CARPETA_PLANTILLAS = path.resolve(__dirname, 'templates');
const MODULO_OCULTO = path.join(__dirname, 'secretmodule.js');

fs.mkdirSync(CARPETA_PLANTILLAS, { recursive: true });

fs.writeFileSync(MODULO_OCULTO, `
module.exports = {
  getFlag: () => "¡Encontraste la flag! Es: ${FLAG_INTERNA}"
};
`);

fs.writeFileSync(path.join(CARPETA_PLANTILLAS, 'normal.js'), `
module.exports = {
  getFlag: () => 'Este módulo no contiene la flag. Intenta con otro.'
};
`);

servidor.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

servidor.get('/style.css', (req, res) => {
  res.sendFile(path.join(__dirname, 'style.css'));
});

servidor.get('/load_template', (req, res) => {
  const nombrePlantilla = req.query.name;

  if (!nombrePlantilla) {
    return res.status(400).send("El parámetro 'name' es obligatorio.");
  }

  try {
    if (
      nombrePlantilla.includes('../') ||
      nombrePlantilla.includes('....//') ||
      nombrePlantilla.includes('\\.') ||
      nombrePlantilla.includes('.') ||
      nombrePlantilla.includes('/')
    ) {
      return res.status(400).send("Nombre de plantilla no permitido (ruta sospechosa detectada).");
    }
  } catch {
    return res.status(400).send("Error al procesar la solicitud.");
  }

  const plantillaDecodificada = decodeURIComponent(nombrePlantilla);
  console.log("Intentando cargar:", plantillaDecodificada);

  try {
    const rutaModulo = path.join(CARPETA_PLANTILLAS, plantillaDecodificada);
    const moduloCargado = require(rutaModulo);

    if (typeof moduloCargado.getFlag === 'function') {
      res.send(moduloCargado.getFlag());
    } else {
      res.send("Módulo cargado, pero no contiene la función esperada.");
    }
  } catch (err) {
    console.error("Error al cargar módulo:", err);
    res.status(500).send("No se pudo cargar el módulo. Revisa el nombre o la ruta.");
  }
});

servidor.listen(3000, () => {
  console.log('Servidor en marcha → http://localhost:3000');
});
