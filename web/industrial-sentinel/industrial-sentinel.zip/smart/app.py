from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import sqlite3
import requests
from urllib.parse import urlparse
from datetime import datetime
import os
from config import Config

app = Flask(__name__)
app.config.from_object(Config)

def get_db_connection():
    conn = sqlite3.connect(app.config['DATABASE_PATH'])
    conn.row_factory = sqlite3.Row
    return conn

def log_access(username, endpoint, ip):
    log_path = '/app/data/logs/access.log'
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    with open(log_path, 'a') as f:
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f"[{timestamp}] User: {username}, Endpoint: {endpoint}, IP: {ip}\n")

@app.route('/')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))
    return redirect(url_for('dashboard'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        conn = get_db_connection()
        user = conn.execute(
            'SELECT * FROM users WHERE username = ? AND password = ?',
            (username, password)
        ).fetchone()
        conn.close()
        
        if user:
            session['username'] = user['username']
            session['role'] = user['role']
            log_access(username, '/login', request.remote_addr)
            return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error='Credenciales inválidas')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    production_data = []
    
    for line in range(1, 5):
        data = conn.execute('''
            SELECT * FROM production_data 
            WHERE line_id = ? 
            ORDER BY timestamp DESC 
            LIMIT 1
        ''', (line,)).fetchone()
        
        if data:
            production_data.append(dict(data))
    
    conn.close()
    
    return render_template('dashboard.html', 
                         production_data=production_data,
                         username=session['username'],
                         role=session['role'])

@app.route('/sensor-verification')
def sensor_verification():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    return render_template('sensor_verify.html',
                         username=session['username'],
                         role=session['role'])

@app.route('/api/verify-external-sensor')
def verify_sensor():
    if 'username' not in session:
        return jsonify({'error': 'No autenticado'}), 401
    
    sensor_url = request.args.get('url')
    
    if not sensor_url:
        return jsonify({'error': 'Proporciona URL del sensor'}), 400
    
    log_access(session['username'], f'/api/verify-external-sensor?url={sensor_url}', request.remote_addr)
    
    parsed = urlparse(sensor_url)
    
    blocked_hosts = ['localhost', '127.0.0.1', '0.0.0.0', 'metadata', '169.254.169.254']
    hostname_lower = parsed.netloc.lower().split(':')[0]
    
    if any(blocked in hostname_lower for blocked in blocked_hosts):
        return jsonify({
            'error': f'Host bloqueado por políticas de seguridad: {parsed.netloc}',
            'hint': 'Algunos formatos de IP pueden no estar bloqueados...'
        }), 403
    
    if parsed.port and parsed.port not in [80, 443, 8080, 8888, 5000]:
        return jsonify({
            'error': 'Puerto no permitido',
            'allowed_ports': [80, 443, 8080, 8888, 5000]
        }), 403
    
    try:
        response = requests.get(
            sensor_url, 
            timeout=5,
            allow_redirects=True,
            headers={'User-Agent': 'FactoryMonitor/2.1'}
        )
        
        return jsonify({
            'status': 'success',
            'url': sensor_url,
            'sensor_response': response.text[:1000],
            'status_code': response.status_code,
            'content_type': response.headers.get('Content-Type', 'unknown'),
            'hint': 'Los servicios internos de la plataforma están en localhost...'
        })
    
    except requests.exceptions.Timeout:
        return jsonify({'error': 'Timeout conectando al sensor'}), 504
    
    except requests.exceptions.ConnectionError as e:
        return jsonify({
            'error': f'Error de conexión: {str(e)}',
            'hint': 'Verifica que el sensor esté accesible'
        }), 502
    
    except requests.exceptions.RequestException as e:
        return jsonify({'error': f'Error en la petición: {str(e)}'}), 500

@app.route('/internal/metadata/v1/instance/service-accounts/default/token')
def internal_metadata():
    client_ip = request.remote_addr
    
    if client_ip not in ['127.0.0.1', '::1']:
        return jsonify({
            'error': 'Forbidden',
            'message': 'Metadata service only accessible from localhost'
        }), 403
    
    return jsonify({
        'access_token': 'ya29.c.Kl6iB-factory-secret-token-2024',
        'expires_in': 3599,
        'token_type': 'Bearer',
        'scope': 'https://factory-api.internal/admin',
        'admin_api_key': app.config['INTERNAL_API_KEY']
    })

@app.route('/internal/admin-api/system-info')
def internal_admin_info():
    api_key = request.headers.get('X-API-Key') or request.args.get('api_key')
    
    if not api_key:
        return jsonify({
            'error': 'Missing API Key',
            'hint': 'X-API-Key header or api_key query parameter required'
        }), 401
    
    if api_key != app.config['INTERNAL_API_KEY']:
        return jsonify({
            'error': 'Invalid API key',
            'provided': api_key[:10] + '...' if len(api_key) > 10 else api_key
        }), 403
    
    # FLAG FINAL
    return jsonify({
        'status': 'success',
        'flag': 'ikerlan{fake_flag}',
        'system_info': {
            'version': '2.1.3',
            'database': app.config['DATABASE_PATH'],
            'factory_name': app.config['FACTORY_NAME'],
            'internal_services': [
                'metadata-service:8080',
                'admin-api:5000',
                'monitoring-agent:9090'
            ]
        }
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)