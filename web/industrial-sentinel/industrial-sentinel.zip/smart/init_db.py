import sqlite3
import os
from datetime import datetime, timedelta
import random

DATABASE_PATH = '/app/data/factory.db'

def init_database():
    os.makedirs(os.path.dirname(DATABASE_PATH), exist_ok=True)
    
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS production_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            line_id INTEGER NOT NULL,
            temperature REAL NOT NULL,
            pressure REAL NOT NULL,
            speed INTEGER NOT NULL,
            status TEXT NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    users = [
        ('operator', 'factory2024', 'operator'),
        ('supervisor', 'super123', 'supervisor'),
        ('admin', 'admin2024', 'admin')
    ]
    
    for username, password, role in users:
        try:
            cursor.execute(
                'INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
                (username, password, role)
            )
        except sqlite3.IntegrityError:
            pass
    
    statuses = ['running', 'idle', 'maintenance']
    
    for line in range(1, 5):
        for _ in range(10):
            temperature = round(random.uniform(60, 90), 2)
            pressure = round(random.uniform(2.0, 5.0), 2)
            speed = random.randint(800, 1200)
            status = random.choice(statuses)
            
            cursor.execute('''
                INSERT INTO production_data 
                (line_id, temperature, pressure, speed, status)
                VALUES (?, ?, ?, ?, ?)
            ''', (line, temperature, pressure, speed, status))
    
    conn.commit()
    conn.close()
    
    print(f"Base de datos inicializada: {DATABASE_PATH}")
    print("Usuarios creados:")
    print("   - operator:factory2024 (operator)")
    print("   - supervisor:super123 (supervisor)")
    print("   - admin:admin2024 (admin)")

if __name__ == '__main__':
    init_database()