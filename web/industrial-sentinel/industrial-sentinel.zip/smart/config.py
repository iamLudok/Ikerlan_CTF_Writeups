import os
import secrets

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
    
    DATABASE_PATH = os.environ.get('DATABASE_PATH') or '/app/data/factory.db'
    
    FACTORY_NAME = 'Ikerlan Industrial Plant'
    
    INTERNAL_API_KEY = 'fake_api'
    
    DEFAULT_USERS = [
        {'username': 'operator', 'password': 'factory2024', 'role': 'operator'},
        {'username': 'supervisor', 'password': 'super123', 'role': 'supervisor'},
        {'username': 'admin', 'password': 'admin2024', 'role': 'admin'}
    ]